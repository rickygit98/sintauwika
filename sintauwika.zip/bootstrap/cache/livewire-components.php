<?php return array (
  'admin.admin-dosen' => 'App\\Http\\Livewire\\Admin\\AdminDosen',
  'admin.admin-mahasiswa' => 'App\\Http\\Livewire\\Admin\\AdminMahasiswa',
  'admin.admin-topik' => 'App\\Http\\Livewire\\Admin\\AdminTopik',
  'admin.admin-user' => 'App\\Http\\Livewire\\Admin\\AdminUser',
);