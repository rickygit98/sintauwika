
<?php $__env->startSection('content'); ?>

    <?php if($bimbingan): ?>
        

        <h3>History Skripsi Saya</h3>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Sender</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Comment</th>
                    <th scope="col">Link</th>
                    <th scope="col">File</th>
                    <th scope="col">Last update</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bimbingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bmb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <th scope="row"><?php echo e($bmb->sender); ?></th>
                        <th scope="row"><?php echo e($bmb->subject); ?></th>
                        <td><?php echo $bmb->comment; ?></td>

                        <?php if($bmb->link): ?>

                            <td><a href="<?php echo e($bmb->link); ?>" target="blank"><i class="fas fa-globe me-2"></i>Link File</a>
                            </td>
                        <?php else: ?>
                            <td>None </td>
                        <?php endif; ?>

                        <?php if($bmb->file): ?>
                            <td><a href="/download/?file=<?php echo e($bmb->file); ?>"><i class="fas fa-file-alt me-2"></i>Download
                                    File</a>
                            </td>

                        <?php else: ?>
                            <td>None </td>

                        <?php endif; ?>
                        <td scope="row"><?php echo e($bmb->created_at->diffForHumans()); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php else: ?>
        
        

        <h3>History Skripsi Saya</h3>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">comment</th>
                    <th scope="col">Dosen Pembimbing</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <div class="alert">
            <p>
                <strong>Belum Ada history</strong> untuk skripsi anda , pastikan topik anda sudah disetujui dan minimal
                melakukan bimbingan 1 kali dengan
                dosen pembimbing kamu
            </p>
        </div>
    <?php endif; ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mhsmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views//mahasiswa/bimbingan/index.blade.php ENDPATH**/ ?>