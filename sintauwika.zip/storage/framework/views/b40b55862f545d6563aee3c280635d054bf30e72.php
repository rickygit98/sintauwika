<nav class="main-header navbar navbar-expand navbar-black navbar-dark">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="/home" class="nav-link">Home</a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="/about" class="nav-link">About</a>
        </li>
    </ul>

    <!-- Right navbar links -->
    

    <ul class="navbar-nav ml-auto">

        <li class="nav-item">
            <a class="nav-link nav-icon" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

                <i class="nav-icon fas fa-sign-out-alt"></i>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>

        </li>
    </ul>
</nav>
<?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views/layouts/header.blade.php ENDPATH**/ ?>