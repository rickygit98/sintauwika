<?php if($topik->count() == 0): ?>
    <div class="col-12">
        <div class="card">

            <?php if(session()->has('success')): ?>
                <div class="mx-3">
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <i data-feather="check"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card-header">
                <h3 class="card-title">Belum ada Topik yang diajukan saat ini</h3>
            </div>
            <!-- ./card-header -->
            <div class="card-body">
                <img src="https://64.media.tumblr.com/f74633365530a38b62a3b30f3d41e8cf/2335c431e4074bd3-c2/s1280x1920/aaf32833587c816ffbf2921ce51d9f958e6a0160.jpg"
                    style="width:200px" alt="">
            </div>
        </div>
    </div>

<?php else: ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">DAFTAR TOPIK</h3>
            </div>
            <!-- ./card-header -->
            <div class="card-body">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Judul Topik</th>
                            <th>Kategori Topik</th>
                            <th>Mahasiswa</th>
                            <th>Pembimbing</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $topik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-widget="expandable-table" aria-expanded="false">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($t->title); ?></td>
                                <td><?php echo e($t->kategori->name); ?></td>
                                <td><?php echo e($t->mahasiswa->user->name); ?></td>
                                <td><?php echo e($t->dosen->user->name); ?></td>
                                <?php if($t->status == 'Diterima'): ?>
                                    <td><span class="badge badge-success p-2"><?php echo e($t->status); ?></span></td>
                                <?php else: ?>
                                    <td><span class="badge badge-danger p-2"><?php echo e($t->status); ?></span></td>
                                <?php endif; ?>
                                <td>
                                    <button class="badge bg-primary border-0 p-2" type="button" data-bs-toggle="modal"
                                        data-bs-target="#showTopik" wire:click.prevent='showTopik(<?php echo e($t->id); ?>)'>
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php echo $__env->make('admin.topik.showTopik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </td>

                            </tr>
                            <tr class="expandable-body d-none">
                                <td colspan="8">
                                    <p style="display: none;">
                                        <?php echo $t->comment; ?>

                                    </p>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>






<?php endif; ?>
<?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views//admin/topik/index.blade.php ENDPATH**/ ?>