<!doctype html>
<html lang="en">

<head>
    <?php echo $__env->make('layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title>Kartu Bimbingan</title>
</head>

<body>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <!-- Main content -->
                    <div class="invoice p-3 mb-3">

                        <img src="/img/approve.png" alt="" srcset="" class='position-absolute'
                            style="width: 100px; right:10px;">


                        <!-- title row -->
                        <div class="row">
                            <div class="col-12">
                                <h4>
                                    <i class="fas fa-globe"></i> <?php echo e($skripsi->topik->title); ?>

                                </h4>
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- info row -->
                        <div class="row invoice-info">
                            <div class="col-sm-4 invoice-col">
                                From
                                <address>
                                    <strong>Mahasiswa</strong>

                                    <br>Name: <?php echo e($skripsi->topik->mahasiswa->user->name); ?>

                                    <br>Phone: <?php echo e($skripsi->topik->mahasiswa->user->contact); ?>

                                    <br>Email: <?php echo e($skripsi->topik->mahasiswa->user->email); ?>

                                </address>
                            </div>

                            <!-- /.col -->

                            <div class="col-sm-4 invoice-col">
                                To
                                <address>
                                    <strong>Dosen Pembimbing</strong>

                                    <br>Name: <?php echo e($skripsi->topik->dosen->user->name); ?>

                                    <br>Phone: <?php echo e($skripsi->topik->dosen->user->contact); ?>

                                    <br>Email: <?php echo e($skripsi->topik->dosen->user->email); ?>

                                </address>
                            </div>
                            <!-- /.col -->

                        </div>
                        <!-- /.row -->

                        <!-- Table row -->
                        <div class="row">
                            <div class="col-12 table-responsive">

                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Subject</th>
                                            <th>Comment</th>
                                            <th>Last update</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <tr>
                                            <td>1</td>
                                            <td><?php echo e($skripsi->subject); ?></td>
                                            <td><?php echo $skripsi->comment; ?></td>
                                            <td><?php echo e($skripsi->updated_at->diffForHumans()); ?></td>
                                        </tr>


                                    </tbody>
                                </table>


                                
                                <div class="row">
                                    <div class="col-12">
                                        <h4>
                                            <i class="fas fa-globe"></i> History Bimbingan
                                        </h4>
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Sender</th>
                                            <th>Subject</th>
                                            <th>Comment</th>
                                            <th>Last update</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $bimbingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bmb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($bmb->sender); ?></td>
                                                <td><?php echo e($bmb->subject); ?></td>
                                                <td><?php echo $bmb->comment; ?></td>
                                                <td><?php echo e($bmb->updated_at->diffForHumans()); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>

                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.invoice -->
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>

    <?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views/kartuBimbinganPdf.blade.php ENDPATH**/ ?>