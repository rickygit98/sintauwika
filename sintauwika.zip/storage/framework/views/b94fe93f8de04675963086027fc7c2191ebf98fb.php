
<?php $__env->startSection('content'); ?>
    <!-- Page Content  -->
    <?php if(session()->has('success')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i data-feather="check"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-center text-center">

        <div class="card d-inline-block col-10">
            <div class="card-header">Hi! <?php echo e(Auth::user()->name); ?></div>
            <div class="card-body">
                <p>
                <h5>
                    Welcome!! <?php echo e(Auth::user()->name); ?>

                </h5>
                </p>
                <br>
                <p>
                    Hi! Pejuang skripsi , selamat datang di aplikasi bimbingan skripsi UWIKA
                </p>
                <p>
                    Kami berharap dapat membantu anda sebaik mungkin agar dapat melakukan bimbingan skripsi dengan lancar
                    hingga
                    akhir.
                    Tetap semangat ! dan rajin belajar !
                </p>
            </div>
        </div>
    </div>
    


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mhsmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views/mahasiswa/dashboard.blade.php ENDPATH**/ ?>