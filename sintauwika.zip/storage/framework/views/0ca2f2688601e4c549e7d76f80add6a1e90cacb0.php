<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SINTA UWIKA | LOG IN</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="adminlte/plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="adminlte/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="adminlte/dist/css/adminlte.min.css">
    <style type="text/css"></style>

    <style>
        .addremoved {
            display: none;
        }

    </style>

</head>

<body>

    <nav class="navbar navbar-expand-md navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                SINTA UWIKA APP
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav me-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto">
                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <!-- <li class="nav-item dropdown"> -->
                        <!-- <a>
                                                                                                                                                                                                <?php echo e(Auth::user()->name); ?>

                                                                                                                                                                                            </a> -->


                        <!-- </li> -->
                        <?php
                    if(Auth::user()->role_id == 1){
                        $ad = DB::table('admins')->where('user_id', Auth::id() )->first();
                        ?>
                        <h4>Admin role</h4>
                        <p style="color:red;margin-left: 5px;margin-right: 20px;"><?php echo e($ad->id_num); ?></p>
                        <?php 
                    }
                    else if(Auth::user()->role_id == 2){
                        $le = DB::table('lecturers')->where('user_id', Auth::id() )->first();
                        ?>
                        <h4>Dosen role</h4>
                        <p style="color:red;margin-left: 5px;margin-right: 20px;"><?php echo e($le->nip); ?></p>
                        <?php 
                     }
                    else if(Auth::user()->role_id == 3){
                        $st = DB::table('students')->where('user_id', Auth::id() )->first();
                        ?>
                        <h4>Mahasiswa role</h4>
                        <p style="color:red;margin-left: 5px;margin-right: 20px;"><?php echo e($st->nrp); ?></p>
                        <?php 
                    }
                    ?>
                        <div>
                            <a class="btn btn-primary" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                                                                                                                                                                                 document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>


    <?php echo $__env->yieldContent('content'); ?>



    <script>
        function changeRole(role) {
            if (role == 1) {
                document.getElementById("an").classList.remove("addremoved")
                document.getElementById("ln").classList.add("addremoved")
                document.getElementById("sn").classList.add("addremoved")
            } else if (role == 2) {
                document.getElementById("ln").classList.remove("addremoved")
                document.getElementById("an").classList.add("addremoved")
                document.getElementById("sn").classList.add("addremoved")

            } else if (role == 3) {
                document.getElementById("sn").classList.remove("addremoved")
                document.getElementById("an").classList.add("addremoved")
                document.getElementById("ln").classList.add("addremoved")
            } else {
                document.getElementById("sn").classList.add("addremoved")
                document.getElementById("an").classList.add("addremoved")
                document.getElementById("ln").classList.add("addremoved")
            }
        }
    </script>

    <!-- jQuery -->
    <script src="adminlte/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="adminlte/dist/js/adminlte.min.js"></script>
</body>

</html>
<?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views/layouts/authmain.blade.php ENDPATH**/ ?>