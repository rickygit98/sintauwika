<!-- Main content -->

<?php $__env->startSection('content'); ?>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <i data-feather="check"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if($skripsi->count() == 0): ?>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Belum ada Topik yang diajukan saat ini</h3>
                </div>
                <!-- ./card-header -->
                <div class="card-body">
                    <img src="https://64.media.tumblr.com/f74633365530a38b62a3b30f3d41e8cf/2335c431e4074bd3-c2/s1280x1920/aaf32833587c816ffbf2921ce51d9f958e6a0160.jpg"
                        style="width:200px" alt="">
                </div>
            </div>
        </div>

    <?php else: ?>
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">DAFTAR SKRIPSI</h3>
                </div>
                <!-- ./card-header -->
                <div class="card-body">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Judul Skripsi</th>
                                <th>Mahasiswa</th>
                                <th>Pembimbing</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $skripsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-widget="expandable-table" aria-expanded="false">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($sk->topik->title); ?></td>
                                    <td><?php echo e($sk->topik->mahasiswa->user->name); ?></td>
                                    <td><?php echo e($sk->topik->dosen->user->name); ?></td>
                                    <?php if($sk->status == 'Approve'): ?>
                                        <td> <span class="badge badge-success p-2"><?php echo e($sk->status); ?></span> </td>
                                    <?php else: ?>
                                        <td> <span class="badge badge-danger p-2"><?php echo e($sk->status); ?></span> </td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="/admin/skripsi/<?php echo e($sk->id); ?>" class="badge bg-primary p-2">
                                            <i class="fas fa-eye fa-lg"></i>
                                        </a>

                                        <?php if($sk->status == 'Approve'): ?>
                                            <?php if($sk->jadwal->tgl_sidang): ?>
                                                <a href="/admin/jadwal/<?php echo e($sk->jadwal->id); ?>/edit"
                                                    class="badge bg-warning p-2">
                                                    <i class="fas fa-calendar-alt fa-lg"></i> Edit Jadwal
                                                </a>
                                            <?php else: ?>
                                                <a href="/admin/jadwal/<?php echo e($sk->jadwal->id); ?>/edit"
                                                    class="badge bg-primary p-2">
                                                    <i class="fas fa-calendar-alt fa-lg"></i> Tambahkan Jadwal
                                                </a>
                                            <?php endif; ?>

                                        <?php endif; ?>



                                    </td>

                                </tr>
                                <tr class="expandable-body d-none">
                                    <td colspan="3">
                                        <p style="display: none;">
                                            <?php echo $sk->comment; ?>

                                        </p>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views//admin/skripsi/index.blade.php ENDPATH**/ ?>