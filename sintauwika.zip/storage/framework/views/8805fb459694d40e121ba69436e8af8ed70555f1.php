
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col">

                <?php if($skripsi == null): ?>
                    <div class="card">
                        <h5 class="card-header">MAAF</h5>
                        <div class="card-body">
                            <h5 class="card-title">Maaf <?php echo e(Auth::user()->name); ?></h5>
                            <p class="card-text">Anda belum punya skripsi yang diaprove</p>
                            <a href="/mahasiswa/dashboard" class="btn btn-primary">Kembali ke dashboard</a>
                        </div>
                    </div>
                <?php else: ?>

                    <?php if($skripsi->jadwal->tgl_sidang): ?>


                        <div class="card">
                            <h5 class="card-header">SELAMAT</h5>
                            <div class="card-body">
                                <h5 class="card-title">Selamat <?php echo e($skripsi->topik->mahasiswa->user->name); ?> Anda sudah
                                    mendapat jadwal</h5>
                                <br>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"> Jadwal Sidang Anda : <strong>
                                        <?php echo e($skripsi->jadwal->tgl_sidang); ?></strong></li>
                                <li class="list-group-item"> Jadwal Seminar Anda :<strong>
                                        <?php echo e($skripsi->jadwal->tgl_seminar); ?></strong></li>
                                <li class="list-group-item"> Penguji Anda :<strong>
                                        <?php echo e($skripsi->jadwal->penguji); ?></strong></li>
                            </ul>
                            <div class="card-body">
                                <?php if(now() > $skripsi->jadwal->tgl_sidang): ?>
                                    <a href="<?php echo e($skripsi->jadwal->link_sidang); ?>" class="btn btn-primary"> Go to Google
                                        Meet</a>
                                <?php else: ?>
                                    <a href="#" class="btn btn-primary disabled"> Link ini akan aktif
                                        pada tanggal : <?php echo e($skripsi->jadwal->tgl_sidang); ?></a>
                                <?php endif; ?>

                                <?php if(now() > $skripsi->jadwal->tgl_seminar): ?>
                                    <a href="<?php echo e($skripsi->jadwal->link_seminar); ?>" class="btn btn-primary"> Go to Google
                                        Meet</a>
                                <?php else: ?>
                                    <a href="#" class="btn btn-primary disabled"> Link ini akan aktif
                                        pada tanggal : <?php echo e($skripsi->jadwal->tgl_seminar); ?></a>
                                <?php endif; ?>

                            </div>
                        </div>


                    <?php else: ?>
                        <div class="card">
                            <h5 class="card-header">MAAF</h5>
                            <div class="card-body">
                                <h5 class="card-title">Maaf <?php echo e($skripsi->topik->mahasiswa->user->name); ?></h5>
                                <p class="card-text">Anda belum punya jadwal untuk skripsi anda</p>
                                <a href="/mahasiswa/dashboard" class="btn btn-primary">Kembali ke dashboard</a>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mhsmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views//mahasiswa/jadwal/index.blade.php ENDPATH**/ ?>