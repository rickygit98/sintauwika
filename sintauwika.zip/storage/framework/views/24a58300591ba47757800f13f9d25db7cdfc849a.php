<div class="card">
    <div class="card-header">
        <h3 class="card-title">DAFTAR MAHASISWA</h3>
    </div>


    <?php if(session()->has('success')): ?>
        <div class="mx-3">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i>
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('admin.mahasiswa.editMahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.mahasiswa.createMahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.card-header -->
    <div class="card-body">

        <!-- Button trigger modal -->

        <div class="row mb-1">
            <!-- Button trigger modal -->
            <div class="col">

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMhs">
                    Create New User
                </button>
            </div>

            <div class="input-group col-md-6"">

                <input type=" text" class="form-control" placeholder="Search ..." aria-label="searchKeyword"
                aria-describedby="button-addon2" name="keyword" wire:model='keyword'>
            </div>
        </div>

        <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
            <div class="row">
                <div class="col-sm-12 col-md-6"></div>
                <div class="col-sm-12 col-md-6"></div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <table id="example2" class="table table-bordered table-hover dataTable dtr-inline collapsed"
                        role="grid" aria-describedby="example2_info">
                        <thead>
                            <tr role="row">
                                <th class="sorting sorting_asc" tabindex="0" aria-controls="example2" rowspan="1"
                                    colspan="1" aria-sort="ascending"
                                    aria-label="Rendering engine: activate to sort column descending">Name
                                </th>
                                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">NRP</th>
                                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">Email</th>
                                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1"
                                    aria-label="Platform(s): activate to sort column ascending">Contact</th>
                                <th class="sorting" tabindex="0" aria-controls="example2" rowspan="1" colspan="1"
                                    aria-label="CSS grade: activate to sort column ascending">
                                    Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $user->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr class="odd">
                                        <td class="dtr-control sorting_1" tabindex="0"><?php echo e($user->name); ?></td>
                                        <td class="dtr-control sorting_1" tabindex="0"><?php echo e($mhs->nrp); ?></td>
                                        <td class="dtr-control sorting_1" tabindex="0"><?php echo e($user->email); ?></td>
                                        <td class="dtr-control sorting_1" tabindex="0"><?php echo e($user->contact); ?></td>
                                        <td class="dtr-control sorting_1" tabindex="0">


                                            <button wire:click.prevent='showMahasiswa(<?php echo e($user->id); ?>)'
                                                class="badge bg-warning border-0 p-2" type="button"
                                                data-bs-toggle="modal" data-bs-target="#editMhs">
                                                <i class="fas fa-user-edit"></i>
                                            </button>

                                            <button wire:click.prevent='deleteMahasiswaConfirm(<?php echo e($user->id); ?>)'
                                                class="badge bg-danger border-0 p-2" type="button">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
            <div class="d-flex justify-content-end">

                <?php echo e($users->links()); ?>


            </div>
        </div>
    </div>
    <!-- /.card-body -->
</div>
<?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views/admin/mahasiswa/index.blade.php ENDPATH**/ ?>