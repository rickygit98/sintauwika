
<?php $__env->startSection('content'); ?>
    <!-- Page Content  -->
    <section id="">
        <div class="col-lg-8">

            <form action="/mahasiswa/skripsi/<?php echo e($skripsi->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('put'); ?>
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <input type="hidden" class="form-control" id="topik_id" name="topik_id"
                        value="<?php echo e($skripsi->topik->id); ?>">
                </div>

                <div class="mb-3">
                    <label for="title" class="form-label">Title</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" name="title"
                        required value="<?php echo e(old('title', $skripsi->topik->title)); ?>" disabled>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e(message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="kategori_id" class="form-label">Kategori Skripsi</label>
                    <select class="form-select" aria-label="Default select example" id='kategori_id' name='kategori_id'
                        required disabled>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(old('kategori_id', $skripsi->topik->kategori->id) == $kt->id): ?>
                                <option value="<?php echo e($kt->id); ?>" selected><?php echo e($kt->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($kt->id); ?>"><?php echo e($kt->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="dosen_id" class="form-label">Dosen Pembimbing</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['dosen_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="dosen_id"
                        name="dosen_id" required value="<?php echo e(old('dosen_id', $skripsi->topik->dosen->user->name)); ?>"
                        disabled>
                </div>
                <br>

                Bisa pilih salah satu atau keduannya
                <hr>

                <div class="mb-3">
                    <label for="link" class="form-label">Input Link Docs</label>
                    <input class="form-control" type="text" id="link" name="link"
                        value="<?php echo e(old('link', $skripsi->link)); ?>">
                </div>

                <div class="mb-3">
                    <label for="file" class="form-label">Input File</label>
                    <input type="hidden" value="<?php echo e($skripsi->file); ?>" id="old_file" name="old_file">
                    <input class="form-control" type="file" id="file" name="file">
                </div>

                <div class="mb-3">
                    <label for="subject" class="form-label">Subject</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " id="subject"
                        name="subject" required value="<?php echo e(old('subject')); ?>">
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e(message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="comment" class="form-label">Comment</label>
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e(message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input id="comment" type="hidden" name="comment" class="<?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                        value="<?php echo e(old('comment')); ?>">
                    <trix-editor input="comment"></trix-editor>

                </div>


                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mhsmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MateriKuliah\ApkLaravel\sintauwika\resources\views//mahasiswa/skripsi/editSkripsi.blade.php ENDPATH**/ ?>